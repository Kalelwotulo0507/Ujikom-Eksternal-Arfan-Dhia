import React from "react";
import Fetch from "./fetch";

const Cities = () => {
    return (
        <Fetch />
    )
}
export default Cities