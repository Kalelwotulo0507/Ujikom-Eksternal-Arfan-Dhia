import React from "react";
import "./style.css"

const Footer = () => {
    return (
        <div>
            <div className="footer">
                <p>Copyright 2024</p>
            </div>
        </div>
    )
}
export default Footer